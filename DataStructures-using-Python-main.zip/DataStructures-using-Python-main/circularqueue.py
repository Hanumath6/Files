class Node:
  def __init__(self,data):
    self.data=data
    self.next=None
class Queue:
  def __init__(self):
    self.front=None
    self.rear=None
  def enqueue(self,val):
    newnode=Node(val)
    if self.rear is None:
      self.front=newnode
      self.rear=newnode
    else:
      self.rear.next=newnode
      self.rear=newnode
    self.rear.next=self.front
  def dequeue(self):
    if self.front is None:
      print("underflow")
    elif self.front==self.rear:
      self.front=None
      self.rear=None
    else:
      print("dequeue ele",self.front.data)
      self.front=self.front.next
      self.rear.next=self.front
  def peek(self):
    if self.front is None:
      print("underlow")
    else:
      print("top",self.front.data)
  def display(self):
    if self.front is None:
      print("under")
    else:
      current=self.front
      while current is not None:
        print(current.data,end='')
        current=current.next
        if current is self.front:
          break
q=Queue()
while True:
  print("1 enqueue 2 dequeue 3 peek 4display")
  ch=int(input('enter ch'))
  if ch==1:
    val=int(input('enter data'))
    q.enqueue(val)
  elif ch==2:
    q.dequeue()
  elif ch==3:
    q.peek()
  elif ch==4:
    q.display()
  else:
    break
    
