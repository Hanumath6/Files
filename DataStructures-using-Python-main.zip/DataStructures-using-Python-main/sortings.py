#selection sort
lst=[9,34,30,7,12,25,4]
print("Before Sorting: ",lst)
for crntIndx in range(0,len(lst)-1):
  sei=crntIndx #samllest element index
  for cmprIndx in range(crntIndx+1,len(lst)):
    if lst[sei]>lst[cmprIndx]:
      sei=cmprIndx
  temp=lst[crntIndx]
  lst[crntIndx]=lst[sei]
  lst[sei]=temp
  print("After Pass %d: "%(crntIndx+1),lst)
print("bubble sort")
#bubble sort
ary=[34,9,25,7,12,30,4]
print(ary)
for i in range(len(ary)-1):
  for j in range(0,len(ary)-1-i):
    if ary[j] > ary[j+1]:
      tmp=ary[j]
      ary[j]=ary[j+1]
      ary[j+1]=tmp
  print(ary)
print("insertion sort")
#insertion sort
nmbrs=[9,34,30,7,12,25,4]
print(nmbrs)
for crrntIndex in range(1,len(nmbrs)):
  crrntVl=nmbrs[crrntIndex]
  sllei=crrntIndex-1
  while crrntVl<nmbrs[sllei] and sllei>=0:
    nmbrs[sllei+1]=nmbrs[sllei]
    sllei=sllei-1
  nmbrs[sllei+1]=crrntVl
  print(nmbrs)
