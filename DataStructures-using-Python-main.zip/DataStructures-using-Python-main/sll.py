class Node:
  def __init__(self,value):
    self.data=value
    self.next=None
    
    print("Node created")
class LinkedList:
  def __init__(self):
    self.head=None
  def insertLast(self,val):
    newnode=Node(val)
    if self.head==None:
      self.head=newnode
      print("head point to first node")
    else:
      current=self.head
      while current.next!=None:
        current=current.next
      current.next=newnode
  def display(self):
    if self.head==None:
      print("List is empty")
    else:
      current=self.head
      while current!=None:
        print(current.data,end=' ')
        current=current.next
  def insertbegin(self,val):
    newnode=Node(val)
    if self.head==None:
      self.head=newnode
      print("head point to first node")
    else:
      newnode.next=self.head
      self.head=newnode
  def deletebegin(self):
    if self.head is None:
      print("no delete")
    
    else:
      current=self.head
      self.head=current.next
  def deletelast(self):
    if self.head is None:
      print("no delete")
    elif self.head.next==None:
      print(self.head.data,"dletd")
      self.head=None
    else:
      prev=self.head
      current=prev.next
      while current.next!=None:
        prev=current
        current=current.next
      print(current.data,"delete")
      prev.next=None
  def insertBeforeNode(self,value,key):
    if self.head is None:
      print("linked list is empty insertion not possible")
    else:
      newnode=Node(value)
      current=self.head
      if current.data==key:
        newnode.next=self.head
        self.head=newnode
      else:
        current=self.head
        while current.next and current.next.data!=key:
          current=current.next
        if current.next:
          newnode.next=current.next
          current.next=newnode
        else:
          print("key not found",key)
  def insertAfterNode(self,value,key):
      if self.head is None:
        print("list empty")
      else:
        newnode=Node(value)
        current=self.head
        while current:
          if current.data==key:
            newnode.next=current.next
            current.next=newnode
            break
          current=current.next
        else:
          print("node with data",key,"not found")
  def deleteBeforeNode(self,key):
      if self.head is None:
        print("list empty")
      else:
        if self.head.next is None:
          print("list only has one element")
        elif self.head.next.data==key:
          self.head=self.head.next
        else:
          prev=self.head
          current=prev.next
          while current.next and current.next.data!=key:
            prev=current
            current=current.next
          if current.next:
            print(current.data,"deleted")
            prev.next=current.next
          else:
            print("key ele not found")
  def deleteAfterNode(self,key):
        if self.head is None:
          print("list empty")
        else:
          if self.head.next is None:
            print("list has one element")
          else:
            current=self.head
            while current and current.data!=key:
              current=current.next
            if current and current.next:
              current.next=current.next.next
            else:
              print("key elemenet not found")
  def reverse(self):
    if self.head is None:
      print("list empty")
    else:
      current=self.head
      prev=None
      while current:
        nextnode=current.next
        current.next=prev.next
        prev=current
        current=newnode
      self.head=prev
      print("list reversed")
      
      
sll=LinkedList()
while True:
  print("\n1.insert@last 2.display 3. exit 4.insertbegin")
  ch=int(input("enter choice"))
  if ch==1:
    value=int(input("enter Element to be inserted:"))
    sll.insertLast(value)
  elif ch==2:
    sll.display()
  elif ch==3:
    break
  elif ch==4:
    value=int(input("enter Element to be inserted:"))
    sll.insertbegin(value)
  elif ch==5:
    sll.deletebegin()
  elif ch==6:
    sll.deletelast()
  elif ch==7:
    key=int(input('enteer key'))
    value=int(input("enter ele"))
    sll.insertBeforeNode(value,key)
  elif ch==8:
    key=int(input('enteer key'))
    value=int(input("enter ele"))
    sll.insertAfterNode(value,key)
  elif ch==8:
    key=int(input('enteer key'))
    sll.deletetBeforeNode(key)
  elif ch==9:
    key=int(input('enteer key'))
    sll.deletetAfterNode(key)
  elif ch==10:
    sll.reverse()
    
