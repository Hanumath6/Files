class Node:
  def __init__(self,data):
    self.data=data
    self.next=None
    
class Stack:
  def __init__(self):
    self.top=None
  def push(self,ele):
    newnode=Node(ele)
    if self.top is None:
      self.top=newnode
    else:
      newnode.next=self.top
      self.top=newnode
      
  def pop(self):
    if self.top is None:
      print('underflow')
    else:
      current=self.top
      self.top=self.top.next
      print(current.data,"is popped")
      del current
  def peek(self):
    if self.top is None:
      print("stack is empty")
    else:
      print("top element ",self.top.data)
s=Stack()
while True:
  print("1 push 2 pop 3peek 4 break")
  ch=int(input("enter number"))
  if ch==1:
    eke=int(input("enter data"))
    s.push(eke)
  elif ch==2:
    s.pop()
  elif ch==3:
    s.peek()
  else:
    break
      
