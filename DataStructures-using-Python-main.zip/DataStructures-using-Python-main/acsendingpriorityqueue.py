class Node:
  def __init__(self,v,p):
    self.data=v
    self.prty=p
    self.next=None
class PQueue:
  def __init__(self):
    self.front=None
  def enq(self,val,pri):
    newnode=Node(val,pri)
    if self.front is None:
      self.front=newnode
    elif pri<self.front.prty:
      newnode.next=self.front
      self.front=newnode
    else:
      current=self.front
      while current.next and pri>=current.next.prty:
        current=current.next
      newnode.next=current.next
      current.next=newnode
  def deq(self):
    if self.front is None:
      print("Queue underflow")
    else:
      print(self.front.data,"delete")
      self.front=self.front.next
  def peek(self):
    if self.front is None:
      print("queue empty")
    else:
      print("peek ele",self.front.data)
      
  def display(self):
    if self.front is None:
      print("queue empty")
    else:
      current=self.front
      while current is not None:
        print(current.data)
        current=current.next
        
p=PQueue()
while True:
  print("1.insert 2.delet 3 peek 4 display 5 exit")
  ch=int(input("enter choice"))
  if ch==1:
    value=int(input("enter value"))
    priority=int(input("enter priotity"))
    p.enq(value,priority)
  elif ch==2:
    p.deq()
  elif ch==3:
    p.peek()
  elif ch==4:
    p.display()
  else:
    break
